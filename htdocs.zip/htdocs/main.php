<html>
<body bgcolor='pink'>
    <center><h1>plz enter valid mail pwd</h1>
    </center>
    </body>
    </html>